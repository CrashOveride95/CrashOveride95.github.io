/* GENERATED FILE, DO NOT EDIT! */

/* gtState_t structure offsets for assembly language: */
#define GT_STATE_SIZE			88
#define GT_STATE_OFF_RENDSTATE		0x00
#define GT_STATE_OFF_TEXSTATE		0x04
#define GT_STATE_OFF_VTXCOUNT		0x08
#define GT_STATE_OFF_VTXV0		0x09
#define GT_STATE_OFF_TRICOUNT		0x0a
#define GT_STATE_OFF_RDPCMDS		0x0c
#define GT_STATE_OFF_OTHERMODE		0x10
#define GT_STATE_OFF_TRANSFORM		0x18
