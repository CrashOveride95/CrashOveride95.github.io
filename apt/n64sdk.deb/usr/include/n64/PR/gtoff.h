/* GENERATED FILE, DO NOT EDIT! */

/* gtState_t structure offsets for assembly language: */
#define GT_STATE_SIZE			176
#define GT_STATE_OFF_RENDSTATE		0x00
#define GT_STATE_OFF_TEXSTATE		0x08
#define GT_STATE_OFF_VTXCOUNT		0x10
#define GT_STATE_OFF_VTXV0		0x11
#define GT_STATE_OFF_TRICOUNT		0x12
#define GT_STATE_OFF_RDPCMDS		0x18
#define GT_STATE_OFF_OTHERMODE		0x20
#define GT_STATE_OFF_TRANSFORM		0x30
