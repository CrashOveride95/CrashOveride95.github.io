/*---------------------------------------------------------------------*
        Copyright (C) 2002 - 2004 BroadOn Communications.
 *---------------------------------------------------------------------*/

#ifndef __bb_fs_h__
#define __bb_fs_h__

#if defined(_LANGUAGE_C) || defined(_LANGUAGE_C_PLUS_PLUS)

#define BB_FL_BLOCK_SIZE	16384
#define BB_INODE16_NAMELEN	11	/* maximum name length */

#endif
#endif
