
This demo uses a simple menu to illustrate the use of various music library
functions.

Once executed use the Dpad to navigate up-down and change setting with 
left-right.  For settings with a large range use the shoulder buttons for
larger changes.  The A button executes the menu command.  The B button
will stop all currently running channels.