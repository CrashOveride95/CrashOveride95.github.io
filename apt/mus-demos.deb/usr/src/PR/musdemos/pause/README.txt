This demo illustrates how to pause and resume songs.

Once executed, use buttons A and B on controller one to pause and
resume the song.  Button A will pause song processing, button B will
resume it.