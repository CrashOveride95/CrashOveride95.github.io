The demos are as follows: 

    crossfade	Fade song in/out using volume API command. 
    effects	Use various sound effect banks. 
    fromram	Sample that plays audio from RAM. 
    fxchange	Change audio library FX type. 
    fxsong	Make it possible to change audio library FX type in a song.
    lookup	Change sample look-up table in song header. 
    marker      Indicate using song marker. 
    nnsched	Use external scheduler. 
    pause	Temporarily stop and restart a song.
    simple	Simple program before and after audio installation.
    testmenu    Example using library based on menus. 

All of the sound data files used in the demos are located in the SoundData directory. 
