This demo illustrates how to use the library with samples based in RAM as
opposed to ROM.
