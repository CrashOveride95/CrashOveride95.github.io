This demo illustrates how the library can allow songs files to change the 
audio library FX type.

Once executed, use button A on controller one to toggle the song change
FX flag.