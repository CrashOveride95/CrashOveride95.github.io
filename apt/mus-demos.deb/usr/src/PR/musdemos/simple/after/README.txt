Simple demo (after music implementation) 
