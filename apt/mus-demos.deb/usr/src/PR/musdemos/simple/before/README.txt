Simple demo (before music implementation)
