This demo explains the method of changing the audio library FX type.

Once executed, use buttons Aand B on controller one to change the FX
type.  Button A increments the FX type, button B decrements the FX type.
