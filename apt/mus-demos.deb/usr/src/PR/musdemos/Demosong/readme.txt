 About "Demo Song" 

This directory contains the sample song (Demosong.sng) and the sample
data required to play it with your Sound Tools hardware.  

It was created on the assumption that it is located in the default 
directory "C:\N64Tools\Demos\Demosong\."  If you have put it into a 
different directory, make the following changes in the N64 Sequencer 
when the song is loaded: 

* Change the directory, where the sample is located, with the
  "Sample bank editor." 
* Change the directory of the sample bank file (.wbk) using
  "Sample bank name" in the "Option menu." 

Use the sample song as a key for learning how to use the N64 Sound 
Tools.  

The sample data is the same as the sample included in 
"/usr/src/PR/asetts/sounds/" of the N64 O/S Library.

