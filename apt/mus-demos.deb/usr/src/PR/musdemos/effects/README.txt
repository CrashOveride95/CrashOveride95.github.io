
This demo illustrates how to use sound effects from different sound effect banks.

Once executed, use button A to start a random sound effect.  Use button B to
silence all sound effects.