This demo illustrates the effect of changing the sample lookup table located in
a song file.

Once executed, use buttons A and B on controller one to change and reset the 
lookup table.  Button A will mix up the lookup table.  Button B will reset the
lookup table.