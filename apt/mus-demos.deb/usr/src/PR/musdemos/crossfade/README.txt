This demo illustrates how to fade one song down while fading another song up.

Once executed use buttons A and B on controller one to fade songs.  Button A will
fade down the current song and fade up song one.  Button B will fade down the current 
song and fade up song two.