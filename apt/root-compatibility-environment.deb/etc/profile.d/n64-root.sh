# Declare the /etc/n64 environment
export ROOT=/etc/n64
