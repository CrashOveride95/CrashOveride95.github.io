------------------------------------------------------------------
NuSystem Sample Program
------------------------------------------------------------------

1. Compiling

	From the terminal, move to the numirror directory.
	For each version, executing the following commands
	from the command shell compiles all 
	programs in the numirror directory.

		make SGISND=1 (Compiles with SGI Sound Library)
		make SGISND=0 (Compiles with N64 Sound Tools)
