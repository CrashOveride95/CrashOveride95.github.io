------------------------------------------------------------------
NuSystem Sample Program
------------------------------------------------------------------

1. Compiling

	From the MS-DOS prompt (MS-DOS or UNIX), move to the 
	numirror directory.  For each version, executing the 
	following commands from the command shell compiles all 
	programs in the numirror directory and below.

		make SGISND=1 (Compiles with SGI Sound Library)
		make SGISND=0 (Compiles with N64 Sound Tools)

2. Miscellaneous

Note that the N64 Sound Tools System must be purchased separately 
to create applications supported by the N64 Sound Tools.  It is 
not necessary to purchase a separate toolkit for SGI Sound 
Library support.
