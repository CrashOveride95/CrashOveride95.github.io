/* ============================================================
          Object Manger Sample   Header Area
 ============================================================ */

/* collision define */



#define COLLISION_GFX_ze1_0 gfx_Shape_of___POLYHEDRON_112_ 
#define COLLISION_VTX_ze1_0 vtx_Shape_of___POLYHEDRON_112_ 
#define COLLISION_GFX_ze1_2_1 gfx_Shape_of___POLYHEDRON_114_ 
#define COLLISION_VTX_ze1_2_1 vtx_Shape_of___POLYHEDRON_114_ 
#define COLLISION_GFX_xe1_2 gfx_Shape_of___POLYHEDRON_116_ 
#define COLLISION_VTX_xe1_2 vtx_Shape_of___POLYHEDRON_116_ 
#define COLLISION_GFX_ze2_0 gfx_Shape_of___POLYHEDRON_118_ 
#define COLLISION_VTX_ze2_0 vtx_Shape_of___POLYHEDRON_118_ 
#define COLLISION_GFX_xe2_1 gfx_Shape_of___POLYHEDRON_120_ 
#define COLLISION_VTX_xe2_1 vtx_Shape_of___POLYHEDRON_120_ 
#define COLLISION_GFX_xe2_2_2 gfx_Shape_of___POLYHEDRON_122_ 
#define COLLISION_VTX_xe2_2_2 vtx_Shape_of___POLYHEDRON_122_ 
#define COLLISION_GFX_ze2_2_3 gfx_Shape_of___POLYHEDRON_124_ 
#define COLLISION_VTX_ze2_2_3 vtx_Shape_of___POLYHEDRON_124_ 
#define COLLISION_GFX_xe3_0 gfx_Shape_of___POLYHEDRON_126_ 
#define COLLISION_VTX_xe3_0 vtx_Shape_of___POLYHEDRON_126_ 
#define COLLISION_GFX_xe3_2_1 gfx_Shape_of___POLYHEDRON_128_ 
#define COLLISION_VTX_xe3_2_1 vtx_Shape_of___POLYHEDRON_128_ 
#define COLLISION_GFX_ze3_2 gfx_Shape_of___POLYHEDRON_130_ 
#define COLLISION_VTX_ze3_2 vtx_Shape_of___POLYHEDRON_130_ 
#define COLLISION_GFX_ze4_0 gfx_Shape_of___POLYHEDRON_132_ 
#define COLLISION_VTX_ze4_0 vtx_Shape_of___POLYHEDRON_132_ 
#define COLLISION_GFX_xe4_1 gfx_Shape_of___POLYHEDRON_134_ 
#define COLLISION_VTX_xe4_1 vtx_Shape_of___POLYHEDRON_134_ 
#define COLLISION_GFX_ze4_2_2 gfx_Shape_of___POLYHEDRON_136_ 
#define COLLISION_VTX_ze4_2_2 vtx_Shape_of___POLYHEDRON_136_ 
#define COLLISION_GFX_xe5_0 gfx_Shape_of___POLYHEDRON_138_ 
#define COLLISION_VTX_xe5_0 vtx_Shape_of___POLYHEDRON_138_ 
#define COLLISION_GFX_ze5_1 gfx_Shape_of___POLYHEDRON_140_ 
#define COLLISION_VTX_ze5_1 vtx_Shape_of___POLYHEDRON_140_ 
#define COLLISION_GFX_ze5_2_2 gfx_Shape_of___POLYHEDRON_142_ 
#define COLLISION_VTX_ze5_2_2 vtx_Shape_of___POLYHEDRON_142_ 

