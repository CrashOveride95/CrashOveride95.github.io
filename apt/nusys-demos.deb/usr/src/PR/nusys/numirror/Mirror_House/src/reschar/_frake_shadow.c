/*======================================================================*/
/*		NIFFprev						*/
/*		frake_walk.c						*/
/*									*/
/*		Copyright (C) 1998, NINTENDO Co,Ltd.			*/
/*									*/
/*======================================================================*/

#ifndef F3DEX_GBI_2
#define F3DEX_GBI_2
#endif

#include <ultra64.h>

#include "inc/frake_shadow.c"
