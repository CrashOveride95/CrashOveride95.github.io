/* ============================================================
          Object Manger Sample   Header Area
 ============================================================ */

/* collision define */



#define COLLISION_GFX_zb1_0 gfx_Shape_of___POLYHEDRON_46_ 
#define COLLISION_VTX_zb1_0 vtx_Shape_of___POLYHEDRON_46_ 
#define COLLISION_GFX_xb1_1 gfx_Shape_of___POLYHEDRON_48_ 
#define COLLISION_VTX_xb1_1 vtx_Shape_of___POLYHEDRON_48_ 
#define COLLISION_GFX_zb2_0 gfx_Shape_of___POLYHEDRON_50_ 
#define COLLISION_VTX_zb2_0 vtx_Shape_of___POLYHEDRON_50_ 
#define COLLISION_GFX_xb2_1 gfx_Shape_of___POLYHEDRON_52_ 
#define COLLISION_VTX_xb2_1 vtx_Shape_of___POLYHEDRON_52_ 
#define COLLISION_GFX_xb2_2_2 gfx_Shape_of___POLYHEDRON_54_ 
#define COLLISION_VTX_xb2_2_2 vtx_Shape_of___POLYHEDRON_54_ 
#define COLLISION_GFX_zb3_0 gfx_Shape_of___POLYHEDRON_56_ 
#define COLLISION_VTX_zb3_0 vtx_Shape_of___POLYHEDRON_56_ 
#define COLLISION_GFX_zb3_2_1 gfx_Shape_of___POLYHEDRON_58_ 
#define COLLISION_VTX_zb3_2_1 vtx_Shape_of___POLYHEDRON_58_ 
#define COLLISION_GFX_xb3_2 gfx_Shape_of___POLYHEDRON_60_ 
#define COLLISION_VTX_xb3_2 vtx_Shape_of___POLYHEDRON_60_ 
#define COLLISION_GFX_xb3_2_3 gfx_Shape_of___POLYHEDRON_62_ 
#define COLLISION_VTX_xb3_2_3 vtx_Shape_of___POLYHEDRON_62_ 
#define COLLISION_GFX_zb4_0 gfx_Shape_of___POLYHEDRON_64_ 
#define COLLISION_VTX_zb4_0 vtx_Shape_of___POLYHEDRON_64_ 
#define COLLISION_GFX_zb5_0 gfx_Shape_of___POLYHEDRON_66_ 
#define COLLISION_VTX_zb5_0 vtx_Shape_of___POLYHEDRON_66_ 
#define COLLISION_GFX_xb5_1 gfx_Shape_of___POLYHEDRON_68_ 
#define COLLISION_VTX_xb5_1 vtx_Shape_of___POLYHEDRON_68_ 

