/*		AUTOMATIC SPRITE
	Generated: Fri Jun 26 05:42:54 PDT 1998
	By command:  /usr/sbin/mksprite opening opening.rgb 32 16 1
	In directory: /usr/people/takae/game

Sprite Name = opening
Image Name = opening.rgb
Sprite xsiz = 32
Sprite ysiz = 16
Image xsiz = 320
Image ysiz = 240
Overlap = 1
subimg opening.rgb tmpimg1917.rgb 0 32 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 223 239
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 223 239
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 207 223
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 207 223
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 191 207
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 191 207
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 175 191
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 175 191
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 159 175
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 159 175
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 143 159
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 143 159
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 127 143
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 127 143
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 111 127
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 111 127
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 95 111
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 95 111
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 79 95
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 79 95
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 63 79
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 63 79
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 47 63
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 47 63
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 31 47
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 31 47
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 32 64 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 64 96 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 96 128 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 128 160 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 160 192 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 192 224 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 224 256 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 256 288 15 31
tmpimg1917.rgb:	SGI imagelib image (33 x 17)
subimg opening.rgb tmpimg1917.rgb 288 319 15 31
tmpimg1917.rgb:	SGI imagelib image (32 x 17)
subimg opening.rgb tmpimg1917.rgb 0 32 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 32 64 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 64 96 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 96 128 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 128 160 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 160 192 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 192 224 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 224 256 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 256 288 0 15
tmpimg1917.rgb:	SGI imagelib image (33 x 16)
subimg opening.rgb tmpimg1917.rgb 288 319 0 15
tmpimg1917.rgb:	SGI imagelib image (32 x 16)
*/ 

#include <PR/sp.h>

#include "Texture/opening_imgs.h"

static Bitmap  opening_bitmaps[] = {

#include "Texture/opening_bms.h"

};

#define NUM_opening_BMS  (sizeof(opening_bitmaps)/sizeof(Bitmap))

static Gfx      opening_dl[NUM_DL(NUM_opening_BMS)];

extern Sprite opening_sprite;

Sprite opening_sprite = {

	0,0,			/* Position: x,y */

	319,239,			/* Sprite size in texels (x,y) */

	1.0,1.0,		/* Sprite Scale: x,y */

	0,0,		/* Sprite Explosion Spacing: x,y */

	SP_TEXSHUF | SP_Z | SP_OVERLAP,			/* Sprite Attributes */
	0x1234,			/* Sprite Depth: Z */

	255,255,255,255,	/* Sprite Coloration: RGBA */

	0,0,NULL,		/* Color LookUp Table: start_index, length, address */

	0,1,			/* Sprite Bitmap index: start index, step increment */

	NUM_opening_BMS,		/* Number of bitmaps */
	NUM_DL(NUM_opening_BMS),	/* Number of display list locations allocated */

	16, 17,			/* Sprite Bitmap Height: Used_height, physical height */
	G_IM_FMT_RGBA,		/* Sprite Bitmap Format */
	G_IM_SIZ_16b,		/* Sprite Bitmap Texel Size */

	opening_bitmaps,		/* Pointer to bitmaps */

	opening_dl,			/* Display list memory */

	NULL			/* next_dl pointer */

};
