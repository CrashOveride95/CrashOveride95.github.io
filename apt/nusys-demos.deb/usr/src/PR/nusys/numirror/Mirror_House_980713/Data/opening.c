/*		AUTOMATIC SPRITE
	Generated: Mon Jun 29 22:01:24 PDT 1998
	By command:  /usr/sbin/mksprite opening Opbg_01.rgb 64 32 0
	In directory: /usr/people/takae/game

Sprite Name = opening
Image Name = Opbg_01.rgb
Sprite xsiz = 64
Sprite ysiz = 32
Image xsiz = 320
Image ysiz = 240
Overlap = 0
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 208 239
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 208 239
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 208 239
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 208 239
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 208 239
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 176 207
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 176 207
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 176 207
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 176 207
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 176 207
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 144 175
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 144 175
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 144 175
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 144 175
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 144 175
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 112 143
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 112 143
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 112 143
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 112 143
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 112 143
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 80 111
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 80 111
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 80 111
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 80 111
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 80 111
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 48 79
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 48 79
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 48 79
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 48 79
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 48 79
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 16 47
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 16 47
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 16 47
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 16 47
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 16 47
tmpimg1812.rgb:	SGI imagelib image (64 x 32)
subimg Opbg_01.rgb tmpimg1812.rgb 0 63 0 15
tmpimg1812.rgb:	SGI imagelib image (64 x 16)
subimg Opbg_01.rgb tmpimg1812.rgb 64 127 0 15
tmpimg1812.rgb:	SGI imagelib image (64 x 16)
subimg Opbg_01.rgb tmpimg1812.rgb 128 191 0 15
tmpimg1812.rgb:	SGI imagelib image (64 x 16)
subimg Opbg_01.rgb tmpimg1812.rgb 192 255 0 15
tmpimg1812.rgb:	SGI imagelib image (64 x 16)
subimg Opbg_01.rgb tmpimg1812.rgb 256 319 0 15
tmpimg1812.rgb:	SGI imagelib image (64 x 16)
*/ 

#include <PR/sp.h>

#include "Texture/opening_imgs.h"

static Bitmap  opening_bitmaps[] = {

#include "Texture/opening_bms.h"

};

#define NUM_opening_BMS  (sizeof(opening_bitmaps)/sizeof(Bitmap))

static Gfx      opening_dl[NUM_DL(NUM_opening_BMS)];

extern Sprite opening_sprite;

Sprite opening_sprite = {

	0,0,			/* Position: x,y */

	320,240,			/* Sprite size in texels (x,y) */

	1.0,1.0,		/* Sprite Scale: x,y */

	0,0,		/* Sprite Explosion Spacing: x,y */

	SP_TEXSHUF | SP_Z | SP_FASTCOPY,			/* Sprite Attributes */
	0x1234,			/* Sprite Depth: Z */

	255,255,255,255,	/* Sprite Coloration: RGBA */

	0,0,NULL,		/* Color LookUp Table: start_index, length, address */

	0,1,			/* Sprite Bitmap index: start index, step increment */

	NUM_opening_BMS,		/* Number of bitmaps */
	NUM_DL(NUM_opening_BMS),	/* Number of display list locations allocated */

	32, 32,			/* Sprite Bitmap Height: Used_height, physical height */
	G_IM_FMT_RGBA,		/* Sprite Bitmap Format */
	G_IM_SIZ_16b,		/* Sprite Bitmap Texel Size */

	opening_bitmaps,		/* Pointer to bitmaps */

	opening_dl,			/* Display list memory */

	NULL			/* next_dl pointer */

};
