/*======================================================================*/
/*		NIFFprev						*/
/*		pack.h							*/
/*									*/
/*		Copyright (C) 1997, NINTENDO Co,Ltd.			*/
/*									*/
/*======================================================================*/
#ifndef __PACK_H__
#define __PACK_H__

#include <ultra64.h>
#ifndef _IS_VIEWER_
#include <assert.h>
#endif

#include "pub.h"

#include "malloc.h"
#include "expad.h"
#include "gfx.h"

#endif  /* #ifndef __PACK_H__  */


