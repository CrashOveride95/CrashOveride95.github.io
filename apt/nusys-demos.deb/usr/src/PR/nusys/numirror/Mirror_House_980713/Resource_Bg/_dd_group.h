/* ============================================================
          Object Manger Sample   Header Area
 ============================================================ */

/* collision define */



#define COLLISION_GFX_zd1_0 gfx_Shape_of___POLYHEDRON_84_ 
#define COLLISION_VTX_zd1_0 vtx_Shape_of___POLYHEDRON_84_ 
#define COLLISION_GFX_zd1_2_1 gfx_Shape_of___POLYHEDRON_86_ 
#define COLLISION_VTX_zd1_2_1 vtx_Shape_of___POLYHEDRON_86_ 
#define COLLISION_GFX_xd1_2 gfx_Shape_of___POLYHEDRON_88_ 
#define COLLISION_VTX_xd1_2 vtx_Shape_of___POLYHEDRON_88_ 
#define COLLISION_GFX_xd1_2_3 gfx_Shape_of___POLYHEDRON_90_ 
#define COLLISION_VTX_xd1_2_3 vtx_Shape_of___POLYHEDRON_90_ 
#define COLLISION_GFX_xd2_0 gfx_Shape_of___POLYHEDRON_92_ 
#define COLLISION_VTX_xd2_0 vtx_Shape_of___POLYHEDRON_92_ 
#define COLLISION_GFX_xd2_2_1 gfx_Shape_of___POLYHEDRON_94_ 
#define COLLISION_VTX_xd2_2_1 vtx_Shape_of___POLYHEDRON_94_ 
#define COLLISION_GFX_zd3_0 gfx_Shape_of___POLYHEDRON_96_ 
#define COLLISION_VTX_zd3_0 vtx_Shape_of___POLYHEDRON_96_ 
#define COLLISION_GFX_zd3_2_1 gfx_Shape_of___POLYHEDRON_98_ 
#define COLLISION_VTX_zd3_2_1 vtx_Shape_of___POLYHEDRON_98_ 
#define COLLISION_GFX_xd3_2 gfx_Shape_of___POLYHEDRON_100_ 
#define COLLISION_VTX_xd3_2 vtx_Shape_of___POLYHEDRON_100_ 
#define COLLISION_GFX_xd3_2_3 gfx_Shape_of___POLYHEDRON_102_ 
#define COLLISION_VTX_xd3_2_3 vtx_Shape_of___POLYHEDRON_102_ 
#define COLLISION_GFX_xd4_0 gfx_Shape_of___POLYHEDRON_104_ 
#define COLLISION_VTX_xd4_0 vtx_Shape_of___POLYHEDRON_104_ 
#define COLLISION_GFX_zd5_0 gfx_Shape_of___POLYHEDRON_106_ 
#define COLLISION_VTX_zd5_0 vtx_Shape_of___POLYHEDRON_106_ 
#define COLLISION_GFX_xd5_1 gfx_Shape_of___POLYHEDRON_108_ 
#define COLLISION_VTX_xd5_1 vtx_Shape_of___POLYHEDRON_108_ 
#define COLLISION_GFX_xd5_2_2 gfx_Shape_of___POLYHEDRON_110_ 
#define COLLISION_VTX_xd5_2_2 vtx_Shape_of___POLYHEDRON_110_ 

