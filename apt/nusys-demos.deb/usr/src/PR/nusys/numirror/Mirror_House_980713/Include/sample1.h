/* Saved by Nintendo 64 Sound Tools Version 3.00 of Jan 17 1999 */

/* Sound Effect Defines For 'sample1.bfx' */

#define FX_KUTSU                0
#define FX_ONAKASUITA           1
#define FX_SELECTIT             2
#define FX_MOUDAMEDA            3
#define FX_OHYEAH               4
#define FX_GETIT                5


/* End Of File */
