/* ============================================================
          Object Manger Sample   Header Area
 ============================================================ */

/* collision define */



#define COLLISION_GFX_xc1_0 gfx_Shape_of___POLYHEDRON_70_ 
#define COLLISION_VTX_xc1_0 vtx_Shape_of___POLYHEDRON_70_ 
#define COLLISION_GFX_xc1_2_1 gfx_Shape_of___POLYHEDRON_72_ 
#define COLLISION_VTX_xc1_2_1 vtx_Shape_of___POLYHEDRON_72_ 
#define COLLISION_GFX_zc2_0 gfx_Shape_of___POLYHEDRON_74_ 
#define COLLISION_VTX_zc2_0 vtx_Shape_of___POLYHEDRON_74_ 
#define COLLISION_GFX_xc3_0 gfx_Shape_of___POLYHEDRON_76_ 
#define COLLISION_VTX_xc3_0 vtx_Shape_of___POLYHEDRON_76_ 
#define COLLISION_GFX_xc4_0 gfx_Shape_of___POLYHEDRON_78_ 
#define COLLISION_VTX_xc4_0 vtx_Shape_of___POLYHEDRON_78_ 
#define COLLISION_GFX_zc5_0 gfx_Shape_of___POLYHEDRON_80_ 
#define COLLISION_VTX_zc5_0 vtx_Shape_of___POLYHEDRON_80_ 
#define COLLISION_GFX_xc5_1 gfx_Shape_of___POLYHEDRON_82_ 
#define COLLISION_VTX_xc5_1 vtx_Shape_of___POLYHEDRON_82_ 

