/* ============================================================
          Object Manger Sample   Header Area
 ============================================================ */

/* collision define */


#if 0	/* TAKAE */

#define COLLISION_GFX_noname0002_0 gfx_Shape_of___POLYHEDRON_8866_ 
#define COLLISION_VTX_noname0002_0 vtx_Shape_of___POLYHEDRON_8866_ 
#define COLLISION_GFX_noname0004_0 gfx_Shape_of___POLYHEDRON_8898_ 
#define COLLISION_VTX_noname0004_0 vtx_Shape_of___POLYHEDRON_8898_ 
#define COLLISION_GFX_noname0006_0 gfx_Shape_of___POLYHEDRON_8930_ 
#define COLLISION_VTX_noname0006_0 vtx_Shape_of___POLYHEDRON_8930_ 
#define COLLISION_GFX_noname0008_0 gfx_Shape_of___POLYHEDRON_8960_ 
#define COLLISION_VTX_noname0008_0 vtx_Shape_of___POLYHEDRON_8960_ 
#define COLLISION_GFX_noname000a_0 gfx_Shape_of___POLYHEDRON_8987_ 
#define COLLISION_VTX_noname000a_0 vtx_Shape_of___POLYHEDRON_8987_ 
#define COLLISION_GFX_noname000c_0 gfx_Shape_of___POLYHEDRON_9018_ 
#define COLLISION_VTX_noname000c_0 vtx_Shape_of___POLYHEDRON_9018_ 
#define COLLISION_GFX_noname000e_0 gfx_Shape_of___POLYHEDRON_9048_ 
#define COLLISION_VTX_noname000e_0 vtx_Shape_of___POLYHEDRON_9048_ 
#define COLLISION_GFX_noname0010_0 gfx_Shape_of___POLYHEDRON_9072_ 
#define COLLISION_VTX_noname0010_0 vtx_Shape_of___POLYHEDRON_9072_ 
#define COLLISION_GFX_noname0012_0 gfx_Shape_of___POLYHEDRON_9101_ 
#define COLLISION_VTX_noname0012_0 vtx_Shape_of___POLYHEDRON_9101_ 
#define COLLISION_GFX_noname0014_0 gfx_Shape_of___POLYHEDRON_9129_ 
#define COLLISION_VTX_noname0014_0 vtx_Shape_of___POLYHEDRON_9129_ 
#define COLLISION_GFX_noname0016_0 gfx_Shape_of___POLYHEDRON_9161_ 
#define COLLISION_VTX_noname0016_0 vtx_Shape_of___POLYHEDRON_9161_ 
#define COLLISION_GFX_noname0018_0 gfx_Shape_of___POLYHEDRON_9182_ 
#define COLLISION_VTX_noname0018_0 vtx_Shape_of___POLYHEDRON_9182_ 
#define COLLISION_GFX_noname001a_0 gfx_Shape_of___POLYHEDRON_9209_ 
#define COLLISION_VTX_noname001a_0 vtx_Shape_of___POLYHEDRON_9209_ 
#define COLLISION_GFX_noname001c_0 gfx_Shape_of___POLYHEDRON_9235_ 
#define COLLISION_VTX_noname001c_0 vtx_Shape_of___POLYHEDRON_9235_ 
#define COLLISION_GFX_noname001e_0 gfx_Shape_of___POLYHEDRON_9271_ 
#define COLLISION_VTX_noname001e_0 vtx_Shape_of___POLYHEDRON_9271_ 
#define COLLISION_GFX_noname0020_0 gfx_Shape_of___POLYHEDRON_9300_ 
#define COLLISION_VTX_noname0020_0 vtx_Shape_of___POLYHEDRON_9300_ 

#else

#define COLLISION_GFX_noname0002_0 gfx_Shape_of___POLYHEDRON_142_ 
#define COLLISION_VTX_noname0002_0 vtx_Shape_of___POLYHEDRON_142_ 
#define COLLISION_GFX_noname0004_0 gfx_Shape_of___POLYHEDRON_144_ 
#define COLLISION_VTX_noname0004_0 vtx_Shape_of___POLYHEDRON_144_ 
#define COLLISION_GFX_noname0006_0 gfx_Shape_of___POLYHEDRON_146_ 
#define COLLISION_VTX_noname0006_0 vtx_Shape_of___POLYHEDRON_146_ 
#define COLLISION_GFX_noname0008_0 gfx_Shape_of___POLYHEDRON_148_ 
#define COLLISION_VTX_noname0008_0 vtx_Shape_of___POLYHEDRON_148_ 
#define COLLISION_GFX_noname000a_0 gfx_Shape_of___POLYHEDRON_150_ 
#define COLLISION_VTX_noname000a_0 vtx_Shape_of___POLYHEDRON_150_ 
#define COLLISION_GFX_noname000c_0 gfx_Shape_of___POLYHEDRON_152_ 
#define COLLISION_VTX_noname000c_0 vtx_Shape_of___POLYHEDRON_152_ 
#define COLLISION_GFX_noname000e_0 gfx_Shape_of___POLYHEDRON_154_ 
#define COLLISION_VTX_noname000e_0 vtx_Shape_of___POLYHEDRON_154_ 
#define COLLISION_GFX_noname0010_0 gfx_Shape_of___POLYHEDRON_156_ 
#define COLLISION_VTX_noname0010_0 vtx_Shape_of___POLYHEDRON_156_ 
#define COLLISION_GFX_noname0012_0 gfx_Shape_of___POLYHEDRON_158_ 
#define COLLISION_VTX_noname0012_0 vtx_Shape_of___POLYHEDRON_158_ 
#define COLLISION_GFX_noname0014_0 gfx_Shape_of___POLYHEDRON_160_ 
#define COLLISION_VTX_noname0014_0 vtx_Shape_of___POLYHEDRON_160_ 
#define COLLISION_GFX_noname0016_0 gfx_Shape_of___POLYHEDRON_162_ 
#define COLLISION_VTX_noname0016_0 vtx_Shape_of___POLYHEDRON_162_ 
#define COLLISION_GFX_noname0018_0 gfx_Shape_of___POLYHEDRON_164_ 
#define COLLISION_VTX_noname0018_0 vtx_Shape_of___POLYHEDRON_164_ 
#define COLLISION_GFX_noname001a_0 gfx_Shape_of___POLYHEDRON_166_ 
#define COLLISION_VTX_noname001a_0 vtx_Shape_of___POLYHEDRON_166_ 
#define COLLISION_GFX_noname001c_0 gfx_Shape_of___POLYHEDRON_168_ 
#define COLLISION_VTX_noname001c_0 vtx_Shape_of___POLYHEDRON_168_ 
#define COLLISION_GFX_noname001e_0 gfx_Shape_of___POLYHEDRON_170_ 
#define COLLISION_VTX_noname001e_0 vtx_Shape_of___POLYHEDRON_170_ 
#define COLLISION_GFX_noname0020_0 gfx_Shape_of___POLYHEDRON_172_ 
#define COLLISION_VTX_noname0020_0 vtx_Shape_of___POLYHEDRON_172_ 

#endif