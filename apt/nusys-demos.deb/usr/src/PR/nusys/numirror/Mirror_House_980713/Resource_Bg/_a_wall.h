/* ============================================================
          Object Manger Sample   Header Area
 ============================================================ */

/* collision define */



#define COLLISION_GFX_za1_0 gfx_Shape_of___POLYHEDRON_8_ 
#define COLLISION_VTX_za1_0 vtx_Shape_of___POLYHEDRON_8_ 
#define COLLISION_GFX_za2_0 gfx_Shape_of___POLYHEDRON_10_ 
#define COLLISION_VTX_za2_0 vtx_Shape_of___POLYHEDRON_10_ 
#define COLLISION_GFX_za3_0 gfx_Shape_of___POLYHEDRON_12_ 
#define COLLISION_VTX_za3_0 vtx_Shape_of___POLYHEDRON_12_ 
#define COLLISION_GFX_za4_0 gfx_Shape_of___POLYHEDRON_14_ 
#define COLLISION_VTX_za4_0 vtx_Shape_of___POLYHEDRON_14_ 
#define COLLISION_GFX_za5_0 gfx_Shape_of___POLYHEDRON_16_ 
#define COLLISION_VTX_za5_0 vtx_Shape_of___POLYHEDRON_16_ 
#define COLLISION_GFX_za4_h_0 gfx_Shape_of___POLYHEDRON_18_ 
#define COLLISION_VTX_za4_h_0 vtx_Shape_of___POLYHEDRON_18_ 
#define COLLISION_GFX_za2_2_0 gfx_Shape_of___POLYHEDRON_228_ 
#define COLLISION_VTX_za2_2_0 vtx_Shape_of___POLYHEDRON_228_ 
#define COLLISION_GFX_xa2_0 gfx_Shape_of___POLYHEDRON_162_ 
#define COLLISION_VTX_xa2_0 vtx_Shape_of___POLYHEDRON_162_ 
#define COLLISION_GFX_xa3_0 gfx_Shape_of___POLYHEDRON_165_ 
#define COLLISION_VTX_xa3_0 vtx_Shape_of___POLYHEDRON_165_ 

