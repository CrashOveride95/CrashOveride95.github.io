/* ============================================================
          Object Manger Sample   Header Area
 ============================================================ */

/* collision define */



#define COLLISION_GFX_za1_0 gfx_Shape_of___POLYHEDRON_8_ 
#define COLLISION_VTX_za1_0 vtx_Shape_of___POLYHEDRON_8_ 
#define COLLISION_GFX_za1_2_1 gfx_Shape_of___POLYHEDRON_10_ 
#define COLLISION_VTX_za1_2_1 vtx_Shape_of___POLYHEDRON_10_ 
#define COLLISION_GFX_xa1_2 gfx_Shape_of___POLYHEDRON_12_ 
#define COLLISION_VTX_xa1_2 vtx_Shape_of___POLYHEDRON_12_ 
#define COLLISION_GFX_za2_0 gfx_Shape_of___POLYHEDRON_14_ 
#define COLLISION_VTX_za2_0 vtx_Shape_of___POLYHEDRON_14_ 
#define COLLISION_GFX_za2_2_1 gfx_Shape_of___POLYHEDRON_16_ 
#define COLLISION_VTX_za2_2_1 vtx_Shape_of___POLYHEDRON_16_ 
#define COLLISION_GFX_xa2_2 gfx_Shape_of___POLYHEDRON_18_ 
#define COLLISION_VTX_xa2_2 vtx_Shape_of___POLYHEDRON_18_ 
#define COLLISION_GFX_za2_3_3 gfx_Shape_of___POLYHEDRON_20_ 
#define COLLISION_VTX_za2_3_3 vtx_Shape_of___POLYHEDRON_20_ 
#define COLLISION_GFX_za3_0 gfx_Shape_of___POLYHEDRON_25_ 
#define COLLISION_VTX_za3_0 vtx_Shape_of___POLYHEDRON_25_ 
#define COLLISION_GFX_xa3_1 gfx_Shape_of___POLYHEDRON_27_ 
#define COLLISION_VTX_xa3_1 vtx_Shape_of___POLYHEDRON_27_ 
#define COLLISION_GFX_za3_2_2 gfx_Shape_of___POLYHEDRON_29_ 
#define COLLISION_VTX_za3_2_2 vtx_Shape_of___POLYHEDRON_29_ 
#define COLLISION_GFX_za4_0 gfx_Shape_of___POLYHEDRON_34_ 
#define COLLISION_VTX_za4_0 vtx_Shape_of___POLYHEDRON_34_ 
#define COLLISION_GFX_za4_h_1 gfx_Shape_of___POLYHEDRON_36_ 
#define COLLISION_VTX_za4_h_1 vtx_Shape_of___POLYHEDRON_36_ 
#define COLLISION_GFX_za4_2_2 gfx_Shape_of___POLYHEDRON_38_ 
#define COLLISION_VTX_za4_2_2 vtx_Shape_of___POLYHEDRON_38_ 
#define COLLISION_GFX_za5_0 gfx_Shape_of___POLYHEDRON_40_ 
#define COLLISION_VTX_za5_0 vtx_Shape_of___POLYHEDRON_40_ 
#define COLLISION_GFX_za5_2_1 gfx_Shape_of___POLYHEDRON_42_ 
#define COLLISION_VTX_za5_2_1 vtx_Shape_of___POLYHEDRON_42_ 
#define COLLISION_GFX_xa5_2 gfx_Shape_of___POLYHEDRON_44_ 
#define COLLISION_VTX_xa5_2 vtx_Shape_of___POLYHEDRON_44_ 

