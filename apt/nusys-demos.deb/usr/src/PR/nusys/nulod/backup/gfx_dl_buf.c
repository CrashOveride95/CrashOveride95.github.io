/*
  Read buffer from display list
 */
#include <nusys.h>
#include "main.h"

Gfx gfx_dl_buf[GFX_DL_BUF_SIZE];
