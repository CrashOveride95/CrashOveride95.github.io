This directory contains LOD sample program.

The LOD model is moving toward the far screen, rotating.
Use the Controller to perform the following actions.

Control Pad up/down		LOD model moves back and forth.
Control Pad left/right		LOD model moves left and right.
Control Stick			LOD model starts to rotate.

A, B				Changes microcode
C button up, right		Changes the far value
C button left, down		Changes the near value
START button			Pause
