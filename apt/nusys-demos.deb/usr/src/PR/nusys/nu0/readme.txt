This directory is the smallest sample source of NuSystem.  

It simply displays a square.

main.c		Main routine/Structure of game processing
		
stage00.c	Create DL/Display processing and game processing

graphic.h	A definition of outside reference for graphics etc.

graphic.c	General routine for graphics

gfxinit.c	A static DL to initialize RSP/RDP. 

spec		Spec file for makerom

