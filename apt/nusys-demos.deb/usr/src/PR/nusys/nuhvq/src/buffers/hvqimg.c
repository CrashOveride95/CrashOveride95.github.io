/* 
 *  NUSYSTEM -HVQ library  Sample program
 * 
 *  FILE : hvqimg.c
 * 
Copyright (C) 1999 NINTENDO Co.,Ltd.
Copyright (C) 1999 MONEGI CORPORATION
 * 
 */

#include <ultra64.h>
#include "localdef.h"

/* HVQ image */
u16 hvqimg[SCREEN_WD*SCREEN_HT];

/* end */

