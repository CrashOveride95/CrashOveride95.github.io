/*============================================================================
  NuSYSTEM sample program [SNAKE TAIL HACK]
  
  font.h
  
  Copyright (C) 1997, NINTENDO Co,Ltd.
  ============================================================================*/

#define TEX_COL_WHITE	0
#define TEX_COL_BLACK	1
#define TEX_COL_RED	2
#define TEX_COL_GREEN	3
#define TEX_COL_BLUE	4
#define TEX_COL_YELLOW	5
#define TEX_COL_PURPLE	6
#define TEX_COL_AQUA	7

extern void	Draw8Font( int, int, int, int );
extern char 	outstring[100];
