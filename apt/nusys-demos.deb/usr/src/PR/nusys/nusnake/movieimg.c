/*--------------------------------------------------
	include
--------------------------------------------------*/
#include <ultra64.h>
#include <PR/gbi.h>
#include "ani01.h"	/*The texture for the movie */
#include "ani02.h"
#include "ani03.h"
#include "ani04.h"
#include "ani05.h"
#include "ani06.h"
#include "ani07.h"
#include "ani08.h"
#include "ani09.h"
#include "ani10.h"
#include "ani11.h"
#include "ani12.h"
#include "ani13.h"
#include "ani14.h"
#include "ani15.h"
#include "ani16.h"
