# Declare the /etc/n64 enviroment
export ROOT=/etc/n64
