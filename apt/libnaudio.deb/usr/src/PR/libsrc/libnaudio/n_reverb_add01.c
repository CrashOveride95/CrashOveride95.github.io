        n_aLoadBuffer(ptr++, before_end<<1, buff, osVirtualToPhysical(curr_ptr));
        n_aLoadBuffer(ptr++, after_end<<1, buff+(before_end<<1), osVirtualToPhysical(r->base));
   } else {
        n_aLoadBuffer(ptr++, count<<1, buff, osVirtualToPhysical(curr_ptr));
   }
