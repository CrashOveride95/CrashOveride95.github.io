  n_aADPCMdec(ptr++, K0_TO_PHYS(f->dc_state), flags, tsam<<1, dramAlign, outp);
