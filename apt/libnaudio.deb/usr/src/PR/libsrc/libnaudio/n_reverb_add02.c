        n_aSaveBuffer(ptr++, before_end<<1, buff, osVirtualToPhysical(curr_ptr));
        n_aSaveBuffer(ptr++, after_end<<1, buff+(before_end<<1), osVirtualToPhysical(r->base));
   } else {
        n_aSaveBuffer(ptr++, FIXED_SAMPLE<<1, buff, osVirtualToPhysical(curr_ptr));
   }
