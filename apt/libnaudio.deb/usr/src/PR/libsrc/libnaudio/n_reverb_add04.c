    {
        s16 tmp;

        tmp = buff >> 8;
        n_aResample(ptr++, osVirtualToPhysical(d->rs->state), d->rs->first, ratio, rbuff + (ramalign<<1), tmp);
      }
