

#ifndef __seq__
#define __seq__

char __alSeqNextDelta (ALSeq *seq, s32 *pDeltaTicks);


#endif /* __seq__ */
