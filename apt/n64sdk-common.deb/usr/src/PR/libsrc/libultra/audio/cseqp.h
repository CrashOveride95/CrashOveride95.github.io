

#ifndef __cseqp__
#define __cseqp__


void	__CSPPostNextSeqEvent(ALCSPlayer *seqp);


#endif /* __cseqp__ */
