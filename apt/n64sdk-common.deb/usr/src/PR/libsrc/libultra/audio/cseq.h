


#ifndef __cseq__
#define __cseq__


char __alCSeqNextDelta(ALCSeq *seq, s32 *pDeltaTicks);


#endif /* __cseq__ */
