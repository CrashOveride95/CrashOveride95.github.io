Among the gu Functions, the following were replaced with the newly
created high speed versions.  With the current version OS they are
not being used.

guMtxIdent
guMtxIdentF
guScale
guScaleF
guNormalize
guTranslate
guTranslateF
guMtxF2L
guRotateF
guMtxL2F
guMtxCatF

The newly created functions are installed in the mgu directory.
