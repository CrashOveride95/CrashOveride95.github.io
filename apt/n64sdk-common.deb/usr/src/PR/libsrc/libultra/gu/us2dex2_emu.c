/*---------------------------------------------------------------------*
	Copyright (C) 1998, Nintendo.
	
	File		us2dex2_emu.c
	Coded    by	Yoshitaka Yasumoto.	Apr 10, 1998.
	
	$Id: us2dex2_emu.c,v 1.3 1998/10/09 06:15:40 has Exp $
 *---------------------------------------------------------------------*/
#define		F3DEX_GBI_2
#include	"us2dex_emu.c"

/*======== End of us2dex2_emu.c ========*/
