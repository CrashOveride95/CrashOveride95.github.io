#define		F3DEX_GBI_2
#include	"sprite.c"
