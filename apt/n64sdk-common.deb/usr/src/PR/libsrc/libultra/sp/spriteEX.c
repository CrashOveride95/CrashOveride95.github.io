#define		F3DEX_GBI
#include	"sprite.c"
