/*============================================================================
  main.h
  ============================================================================*/

#ifndef MAIN_H
#define MAIN_H

/* main loop ID no */
#define GM_MAIN	0
#define MAIN_01      1

extern int main_no;

#endif /* MAIN_H */
