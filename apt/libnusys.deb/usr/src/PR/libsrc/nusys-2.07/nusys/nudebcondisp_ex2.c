/*======================================================================*/
/*		NuSYS							*/
/*		nudebconsole_ex2.c					*/
/*									*/
/*		Copyright (C) 1997, NINTENDO Co,Ltd.			*/
/*									*/
/*======================================================================*/
/* $Id: nudebcondisp_ex2.c,v 1.6 1999/06/10 04:29:57 ohki Exp $	*/
/*======================================================================*/
#define F3DEX_GBI_2
/*   I don't like using this method with C language, but I did it */
/* anyway for better maintainability.                             */
#include "nudebcondisp.c"
