/*======================================================================*/
/*		NuSystem						*/
/*		nuboot_emu.c						*/
/*									*/
/*		Copyright (C) 1999, NINTENDO Co,Ltd.			*/
/*======================================================================*/
/* for EmulaterBoard(Indy Only) */
#define	EMU64
#include "nuboot.c"
