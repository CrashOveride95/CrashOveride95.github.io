/*======================================================================*/
/*		NuSYS							*/
/*		nudebtaskperfbar0_ex2.c					*/
/*									*/
/*		Copyright (C) 1997, NINTENDO Co,Ltd.			*/
/*									*/
/*----------------------------------------------------------------------*/    
/* Ver 1.2	98/07/06	Created by Kensaku Ohki(SLANP)		*/
/*======================================================================*/
/* $Id: nudebtaskperfbar0_ex2.c,v 1.3 1999/06/10 04:40:50 ohki Exp $*/
/*======================================================================*/
#ifdef NU_DEBUG
#define	F3DEX_GBI_2
/*   I don't like using this method with C language, but I did it */
/* anyway for better maintainability.                             */
#include "nudebtaskperfbar0.c"
#endif /* NU_DEBUG */
