/*======================================================================*/
/*		NuSYS							*/
/*		nudebtaskperfbar1_ex2.c					*/
/*									*/
/*		Copyright (C) 1997, NINTENDO Co,Ltd.			*/
/*									*/
/*======================================================================*/
/* $Id: nudebtaskperfbar1_ex2.c,v 1.3 1999/06/10 04:41:37 ohki Exp $*/
/*======================================================================*/
#ifdef NU_DEBUG
#define	F3DEX_GBI_2
/*   I don't like using this method with C language, but I did it */
/* anyway for better maintainability.                             */
#include "nudebtaskperfbar1.c"
#endif /* NU_DEBUG */
