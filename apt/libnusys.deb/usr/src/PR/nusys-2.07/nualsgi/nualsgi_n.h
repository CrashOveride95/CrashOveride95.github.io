/*======================================================================*/
/*		NuSystemAudio Library for SGI Library & naudio		*/
/*		nualsgi.h						*/
/*									*/
/*		Copyright (C) 1997, NINTENDO Co,Ltd.			*/
/*									*/
/*======================================================================*/
/*	$Id: nualsgi_n.h,v 1.1 1998/12/24 11:03:13 ohki Exp $		*/
/*======================================================================*/
#ifndef _NUALSGI_N_H_
#define _NUALSGI_N_H_

#ifndef	N_AUDIO
#define N_AUDIO
#endif	/* N_AUDIO */
#include <nualsgi.h>
    
#endif	/* _NUALSGI_N_H_ */
