/*======================================================================*/
/*		NuSYS	Audio Library for SoundTools Library & n_audio	*/
/*									*/
/*		nualstl_n.h						*/
/*									*/
/*		Copyright (C) 1997, NINTENDO Co,Ltd.			*/
/*======================================================================*/
/* $Id: nualstl_n.h,v 1.1 1999/01/07 12:25:30 ohki Exp $ */
/*======================================================================*/
#ifndef _NUALSTL_N_H_
#define _NUALSTL_N_H_
#ifndef N_AUDIO
#define N_AUDIO
#endif	/* N_AUDIO */
#include <nualstl.h>
#endif	/* _NUALSTL_N_H_ */
