#ifndef _ERRNO_H
#define _ERRNO_H
/*
	errno.h
*/

extern int errno;

/* ANSI */
#define EDOM		33
#define ERANGE		34

#endif
